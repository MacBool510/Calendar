//
//  TestOrientationChanges.swift
//  JTAppleCalendar
//
//  Created by Jay Thomas on 2017-08-19.
//

import UIKit

class TestOrientationChanges: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    

}
